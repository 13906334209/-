import { User } from '@/types';

export const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
};

export const filterUsers = (users: User[], search: string) => {
  if (!search) return users;
  
  return users.filter(
    (user) =>
      user.username.toLowerCase().includes(search.toLowerCase()) ||
      user.email.toLowerCase().includes(search.toLowerCase())
  );
};

export const sortUsers = (users: User[], sortField?: string, sortOrder?: 'ascend' | 'descend') => {
  if (!sortField || !sortOrder) return users;
  
  return [...users].sort((a, b) => {
    const aValue = a[sortField as keyof User];
    const bValue = b[sortField as keyof User];
    
    if (sortOrder === 'ascend') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
}; 