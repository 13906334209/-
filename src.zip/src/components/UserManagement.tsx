'use client';

import React from 'react';
import { Table, Button, Input, Space, Tag, Popconfirm, message } from 'antd';
import { PlusOutlined, SearchOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { User, UserForm as UserFormType } from '@/types';
import { useUsersStore } from '@/store/users';
import { formatDate, filterUsers, sortUsers } from '@/lib/utils';
import UserForm from './UserForm';

const UserManagement: React.FC = () => {
  const { users, loading, tableParams, setTableParams, addUser, updateUser, deleteUser } = useUsersStore();
  const [searchText, setSearchText] = React.useState('');
  const [formVisible, setFormVisible] = React.useState(false);
  const [editingUser, setEditingUser] = React.useState<User | null>(null);
  const [formLoading, setFormLoading] = React.useState(false);

  // 过滤和排序用户数据
  const filteredUsers = React.useMemo(() => {
    let result = filterUsers(users, searchText);
    result = sortUsers(result, tableParams.sortField, tableParams.sortOrder);
    return result;
  }, [users, searchText, tableParams.sortField, tableParams.sortOrder]);

  // 分页数据
  const paginatedUsers = React.useMemo(() => {
    const { current, pageSize } = tableParams.pagination;
    const start = (current - 1) * pageSize;
    const end = start + pageSize;
    return filteredUsers.slice(start, end);
  }, [filteredUsers, tableParams.pagination]);

  const handleTableChange = (pagination: any, filters: any, sorter: any) => {
    setTableParams({
      pagination: {
        current: pagination.current,
        pageSize: pagination.pageSize,
        total: filteredUsers.length,
      },
      sortField: sorter.field,
      sortOrder: sorter.order,
    });
  };

  const handleAdd = () => {
    setEditingUser(null);
    setFormVisible(true);
  };

  const handleEdit = (record: User) => {
    setEditingUser(record);
    setFormVisible(true);
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteUser(id);
      message.success('删除成功！');
    } catch (error) {
      message.error('删除失败！');
    }
  };

  const handleFormSubmit = async (values: UserFormType) => {
    setFormLoading(true);
    try {
      if (editingUser) {
        await updateUser(editingUser.id, values);
        message.success('更新成功！');
      } else {
        await addUser(values);
        message.success('添加成功！');
      }
      setFormVisible(false);
    } catch (error) {
      message.error('操作失败！');
    } finally {
      setFormLoading(false);
    }
  };

  const columns = [
    {
      title: '用户名',
      dataIndex: 'username',
      key: 'username',
      sorter: true,
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
      sorter: true,
    },
    {
      title: '角色',
      dataIndex: 'role',
      key: 'role',
      render: (role: string) => (
        <Tag color={role === 'admin' ? 'red' : 'blue'}>
          {role === 'admin' ? '管理员' : '普通用户'}
        </Tag>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <Tag color={status === 'active' ? 'green' : 'orange'}>
          {status === 'active' ? '激活' : '禁用'}
        </Tag>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => formatDate(date),
      sorter: true,
    },
    {
      title: '更新时间',
      dataIndex: 'updatedAt',
      key: 'updatedAt',
      render: (date: string) => formatDate(date),
      sorter: true,
    },
    {
      title: '操作',
      key: 'action',
      render: (_: any, record: User) => (
        <Space size="middle">
          <Button
            type="link"
            icon={<EditOutlined />}
            onClick={() => handleEdit(record)}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定要删除这个用户吗？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button type="link" danger icon={<DeleteOutlined />}>
              删除
            </Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <div className="p-6">
      <div className="mb-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold">用户管理</h1>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={handleAdd}
        >
          新增用户
        </Button>
      </div>

      <div className="mb-4">
        <Input
          placeholder="搜索用户名或邮箱"
          prefix={<SearchOutlined />}
          value={searchText}
          onChange={(e) => setSearchText(e.target.value)}
          style={{ width: 300 }}
        />
      </div>

      <Table
        columns={columns}
        dataSource={paginatedUsers}
        rowKey="id"
        loading={loading}
        pagination={{
          ...tableParams.pagination,
          total: filteredUsers.length,
          showSizeChanger: true,
          showQuickJumper: true,
          showTotal: (total, range) =>
            `第 ${range[0]}-${range[1]} 条，共 ${total} 条`,
        }}
        onChange={handleTableChange}
      />

      <UserForm
        visible={formVisible}
        onCancel={() => setFormVisible(false)}
        onSubmit={handleFormSubmit}
        initialValues={editingUser || undefined}
        loading={formLoading}
      />
    </div>
  );
};

export default UserManagement; 