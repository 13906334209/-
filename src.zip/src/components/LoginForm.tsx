'use client';

import React from 'react';
import { Form, Input, Button, Card, message } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import { useAuthStore } from '@/store/auth';
import { LoginForm as LoginFormType } from '@/types';

const LoginForm: React.FC = () => {
  const [form] = Form.useForm();
  const { login } = useAuthStore();
  const [loading, setLoading] = React.useState(false);

  const onFinish = async (values: LoginFormType) => {
    setLoading(true);
    try {
      const success = await login(values);
      if (success) {
        message.success('登录成功！');
        window.location.href = '/dashboard';
      } else {
        message.error('用户名或密码错误！');
      }
    } catch (error) {
      message.error('登录失败，请重试！');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <Card title="管理员登录" className="w-96 shadow-lg">
        <Form
          form={form}
          name="login"
          onFinish={onFinish}
          autoComplete="off"
          layout="vertical"
        >
          <Form.Item
            name="username"
            label="用户名"
            rules={[
              { required: true, message: '请输入用户名！' },
              { min: 3, message: '用户名至少3个字符！' },
            ]}
          >
            <Input
              prefix={<UserOutlined />}
              placeholder="请输入用户名"
              size="large"
            />
          </Form.Item>

          <Form.Item
            name="password"
            label="密码"
            rules={[
              { required: true, message: '请输入密码！' },
              { min: 6, message: '密码至少6个字符！' },
            ]}
          >
            <Input.Password
              prefix={<LockOutlined />}
              placeholder="请输入密码"
              size="large"
            />
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              loading={loading}
              size="large"
              className="w-full"
            >
              登录
            </Button>
          </Form.Item>
        </Form>
        
        <div className="text-center text-gray-500 text-sm">
          <p>测试账号：</p>
          <p>管理员：admin / 123456</p>
          <p>普通用户：user / 123456</p>
        </div>
      </Card>
    </div>
  );
};

export default LoginForm; 