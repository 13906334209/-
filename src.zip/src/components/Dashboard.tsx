'use client';

import React from 'react';
import { Card, Row, Col, Statistic, Table } from 'antd';
import { UserOutlined, TeamOutlined, CheckCircleOutlined, StopOutlined } from '@ant-design/icons';
import { useUsersStore } from '@/store/users';
import { formatDate } from '@/lib/utils';

const Dashboard: React.FC = () => {
  const { users } = useUsersStore();

  const stats = React.useMemo(() => {
    const total = users.length;
    const active = users.filter(user => user.status === 'active').length;
    const inactive = users.filter(user => user.status === 'inactive').length;
    const admins = users.filter(user => user.role === 'admin').length;
    const regularUsers = users.filter(user => user.role === 'user').length;

    return { total, active, inactive, admins, regularUsers };
  }, [users]);

  const recentUsers = React.useMemo(() => {
    return users
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
  }, [users]);

  const columns = [
    {
      title: '用户名',
      dataIndex: 'username',
      key: 'username',
    },
    {
      title: '邮箱',
      dataIndex: 'email',
      key: 'email',
    },
    {
      title: '角色',
      dataIndex: 'role',
      key: 'role',
      render: (role: string) => (
        <span className={role === 'admin' ? 'text-red-600' : 'text-blue-600'}>
          {role === 'admin' ? '管理员' : '普通用户'}
        </span>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => (
        <span className={status === 'active' ? 'text-green-600' : 'text-orange-600'}>
          {status === 'active' ? '激活' : '禁用'}
        </span>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (date: string) => formatDate(date),
    },
  ];

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">仪表盘</h1>
      
      <Row gutter={16} className="mb-6">
        <Col span={6}>
          <Card>
            <Statistic
              title="总用户数"
              value={stats.total}
              prefix={<UserOutlined />}
              valueStyle={{ color: '#3f8600' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="激活用户"
              value={stats.active}
              prefix={<CheckCircleOutlined />}
              valueStyle={{ color: '#52c41a' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="禁用用户"
              value={stats.inactive}
              prefix={<StopOutlined />}
              valueStyle={{ color: '#faad14' }}
            />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic
              title="管理员"
              value={stats.admins}
              prefix={<TeamOutlined />}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
      </Row>

      <Row gutter={16}>
        <Col span={12}>
          <Card title="用户角色分布" className="h-80">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>管理员</span>
                <span className="text-red-600 font-bold">{stats.admins}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>普通用户</span>
                <span className="text-blue-600 font-bold">{stats.regularUsers}</span>
              </div>
            </div>
          </Card>
        </Col>
        <Col span={12}>
          <Card title="用户状态分布" className="h-80">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span>激活</span>
                <span className="text-green-600 font-bold">{stats.active}</span>
              </div>
              <div className="flex justify-between items-center">
                <span>禁用</span>
                <span className="text-orange-600 font-bold">{stats.inactive}</span>
              </div>
            </div>
          </Card>
        </Col>
      </Row>

      <Card title="最近添加的用户" className="mt-6">
        <Table
          columns={columns}
          dataSource={recentUsers}
          rowKey="id"
          pagination={false}
          size="small"
        />
      </Card>
    </div>
  );
};

export default Dashboard; 