import { create } from 'zustand';
import { User, UserForm, TableParams } from '@/types';

interface UsersState {
  users: User[];
  loading: boolean;
  tableParams: TableParams;
  setTableParams: (params: Partial<TableParams>) => void;
  fetchUsers: () => Promise<void>;
  addUser: (user: UserForm) => Promise<void>;
  updateUser: (id: string, user: UserForm) => Promise<void>;
  deleteUser: (id: string) => Promise<void>;
}

// Mock 初始用户数据
const initialUsers: User[] = [
  {
    id: '1',
    username: 'admin',
    email: 'admin@example.com',
    role: 'admin',
    status: 'active',
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: '2',
    username: 'user1',
    email: 'user1@example.com',
    role: 'user',
    status: 'active',
    createdAt: '2024-01-02T00:00:00Z',
    updatedAt: '2024-01-02T00:00:00Z',
  },
  {
    id: '3',
    username: 'user2',
    email: 'user2@example.com',
    role: 'user',
    status: 'inactive',
    createdAt: '2024-01-03T00:00:00Z',
    updatedAt: '2024-01-03T00:00:00Z',
  },
];

export const useUsersStore = create<UsersState>((set, get) => ({
  users: initialUsers,
  loading: false,
  tableParams: {
    pagination: {
      current: 1,
      pageSize: 10,
      total: initialUsers.length,
    },
  },
  setTableParams: (params) => {
    set((state) => ({
      tableParams: { ...state.tableParams, ...params },
    }));
  },
  fetchUsers: async () => {
    set({ loading: true });
    // 模拟 API 调用
    await new Promise((resolve) => setTimeout(resolve, 500));
    set({ loading: false });
  },
  addUser: async (userData) => {
    const newUser: User = {
      id: Date.now().toString(),
      ...userData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    set((state) => ({
      users: [...state.users, newUser],
      tableParams: {
        ...state.tableParams,
        pagination: {
          ...state.tableParams.pagination,
          total: state.users.length + 1,
        },
      },
    }));
  },
  updateUser: async (id, userData) => {
    set((state) => ({
      users: state.users.map((user) =>
        user.id === id
          ? { ...user, ...userData, updatedAt: new Date().toISOString() }
          : user
      ),
    }));
  },
  deleteUser: async (id) => {
    set((state) => ({
      users: state.users.filter((user) => user.id !== id),
      tableParams: {
        ...state.tableParams,
        pagination: {
          ...state.tableParams.pagination,
          total: state.users.length - 1,
        },
      },
    }));
  },
})); 