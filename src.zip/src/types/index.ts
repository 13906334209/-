export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
  status: 'active' | 'inactive';
  createdAt: string;
  updatedAt: string;
}

export interface LoginForm {
  username: string;
  password: string;
}

export interface UserForm {
  username: string;
  email: string;
  role: 'admin' | 'user';
  status: 'active' | 'inactive';
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (credentials: LoginForm) => Promise<boolean>;
  logout: () => void;
}

export interface PaginationParams {
  current: number;
  pageSize: number;
  total: number;
}

export interface TableParams {
  pagination: PaginationParams;
  search?: string;
  sortField?: string;
  sortOrder?: 'ascend' | 'descend';
} 